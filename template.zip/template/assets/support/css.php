  
  
    <!-- custom css -->
    <link rel="stylesheet" href="./assets/css/style.css" />
  
  <!-- bootstrap 5 css -->
  <link rel="stylesheet" href="./assets/css/bootstrap@5.0.2.min.css" />

  <!-- FONTAWESOM ICONS CSS-->
  <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.2.1/css/all.css">
  

  
  <!--table css-->
 
  
  <!-- Font Awesome -->
<!--<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"
/>-->

<!--<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
/>-->
<!-- MDB -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css"
  rel="stylesheet"
/>

<!--Link For data table-->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" />
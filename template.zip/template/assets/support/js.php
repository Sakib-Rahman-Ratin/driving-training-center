<!-- jquary 3.7.1 js -->
<script src="./assets/js/jquery.3.7.1.min.js"></script>

<!-- bootstrap 5.0.2 js -->
<script src="./assets/js/bootstrap@5.0.2.min.js"></script>
<script src="./assets/js/bootstrap@5.0.2.bundle.min.js"></script>

<!-- popper js -->
<script src="./assets/js/popper@2.9.2.min.js"></script>

<!-- custom js -->
<script src="./assets/js/custom.js"></script>

<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.js"
></script>

<!--<script type="text/javascript" src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>-->


<!--Link for DataTable-->

<script
  type="text/javascript"
  src="https://code.jquery.com/jquery-3.7.0.js"
></script>

<script
  type="text/javascript"
  src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"
></script>

<script>
	new DataTable('#example');

</script>





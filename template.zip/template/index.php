
<?php 
ob_start();
session_start();
include('./assets/template/header.php');

?>







                <div class='container'>
                    <div class='card'>
                        <div class='card-header'>
                            <h1>Welcome back </h1>
                        </div>
                        <div class='card-body'>
                            <p>Your account type is: Administrator</p>
                        </div>
                    </div>
                </div>












<?php include('./assets/template/footer.php')?>